// a variável video é um objeto json
const videos = [
  {"id": "ZTQcJWixB1k",
    "titulo": "Fetch API in JavaScript for AJAX Developers"
  },
  {"id": "cuEtnrL9-H0",
    "titulo": "Learn Fetch API In 6 Minutes"
  },
  {"id": "BIz02qY5BRA",
    "titulo": "Responsive Web Design Tutorial"
  }
];

for (let i=0; i<videos.length; i++) {
	//acrescente ao #lista-videos um <li> por cada video que contenha o
	//titulo do video e o respetivo thumbnail.
	//Um thumbnail do YouTube obtem-se formando um URL na forma
	// http://i3.ytimg.com/vi/ID_DO_VIDEO/default.jpg
}
