document.addEventListener("DOMContentLoaded", function(){
    let h4 = document.querySelector("#apresentacao h4");
    window.setInterval(function(){
        let agora = new Date();
        h4.textContent = agora.toLocaleTimeString();
    }, 500);  
});



